from django.http import HttpResponse
from . import pyinfo

def info(request):

  return HttpResponse(pyinfo.foo.fullText())
